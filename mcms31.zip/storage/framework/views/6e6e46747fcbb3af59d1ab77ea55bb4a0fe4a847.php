<form method="GET" action="/results" class="search-form">
    <input type="text" placeholder="Search" name="query">
    <button type="submit"><i class="lni lni-search-alt"></i></button>
</form>
<?php /**PATH C:\laragon\www\mcms31\resources\views/includes/search.blade.php ENDPATH**/ ?>