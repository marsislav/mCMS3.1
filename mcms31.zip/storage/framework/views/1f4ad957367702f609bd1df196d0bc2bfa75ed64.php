<?php $__env->startSection('content'); ?>
            <div class="col-lg-3">
                <div class="panel panel-info">
                    <div class="panel-heading text-center">
                         POSTED
                    </div>
                    <div class="panel-body">
                        <h1 class="text-center"><?php echo e($posts_count); ?></h1>
                    </div>
                </div>
            </div>

            <div class="col-lg-3">
                <div class="panel panel-danger">
                    <div class="panel-heading text-center">
                        TRASHED POSTS
                    </div>
                    <div class="panel-body">
                        <h1 class="text-center"><?php echo e($trashed_count); ?></h1>
                    </div>
                </div>
            </div>

            <div class="col-lg-3">
                <div class="panel panel-success">
                    <div class="panel-heading text-center">
                        USERS 
                    </div>
                    <div class="panel-body">
                        <h1 class="text-center"><?php echo e($users_count); ?></h1>
                    </div>
                </div>
            </div>

            <div class="col-lg-3">
                <div class="panel panel-info">
                    <div class="panel-heading text-center">
                        CATEGORIES
                    </div>
                    <div class="panel-body">
                        <h1 class="text-center"><?php echo e($categories_count); ?></h1>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mcms31\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>