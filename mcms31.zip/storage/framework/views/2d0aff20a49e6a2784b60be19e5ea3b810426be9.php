        <div class="container">
            <div class="row">
                <div class="subscribe scrollme">

                    <div class="col-sm-12 col-xs-12">
                      <!--Contact us-->
                        <?php echo Form::open(['url' => 'contact/submit']); ?>

                        <?php echo e(csrf_field()); ?>

                        <div>
                            <?php echo e(Form::text('name', '', ['class'=>'form-control mb-3', 'placeholder'=>'Enter your name'])); ?>

                        </div>
                        <div>
                            <?php echo e(Form::text('email', '', ['class'=>'form-control mb-3', 'placeholder'=>'Enter your email address'])); ?>

                        </div>
                        <div>
                            <?php echo e(Form::textarea('message', '', ['class'=>'form-control mb-3', 'placeholder'=>'Enter message'])); ?>

                        </div>
                        <div>
                            <?php echo e(Form::submit('Send', ['class'=>'theme-btn'])); ?>

                        </div>
                    <?php echo Form::close(); ?>

                        <!--/ Contact us-->

                    </div>
                </div>
            </div>
        </div>

<?php /**PATH C:\laragon\www\mcms31\resources\views/includes/form.blade.php ENDPATH**/ ?>