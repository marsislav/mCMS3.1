<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('site_name');
            $table->string('contact_number');
            $table->string('contact_email');
            $table->string('address');
            $table->text('site_info');
            $table->string('facebook');
            $table->string('instagram');
            $table->string('twitter');
            $table->string('tiktok');
            $table->string('linkedin');
            $table->string('vkontakte');
            $table->string('youtube');
            $table->string('skype');          
            $table->string('footer_text1');
            $table->string('footer_text2');
            $table->string('footer_text3');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }
}
